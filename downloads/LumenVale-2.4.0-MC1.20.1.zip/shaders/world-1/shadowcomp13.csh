#version 430
#define texture2D texture
#define DIM_NETHER
#include "/lib/voxel_bounce_seed.csh"
